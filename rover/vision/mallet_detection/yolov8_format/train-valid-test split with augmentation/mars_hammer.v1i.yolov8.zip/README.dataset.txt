# mars_hammer > 2023-10-24 8:11pm
https://universe.roboflow.com/arwin-s-yofk7/mars_hammer

Provided by a Roboflow user
License: CC BY 4.0

